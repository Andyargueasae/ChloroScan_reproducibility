from Bio import SeqIO
import os
from pathlib import Path
import argparse
# The aim is to deduplicate the sequences inside orthogroups.

parser = argparse.ArgumentParser()
parser.add_argument("orthogroup", metavar="OG", type=Path)
parser.add_argument("output", metavar="OP", type=Path)

args = parser.parse_args()

def deduplication(OG_Seqs):
    # Separate seqs by species, remove the seqs 
    OG_sp_dict = dict()
    OG_Seq_copy = OG_Seqs
    for seq in OG_Seqs:
        seq_id = seq.id
        species = seq_id.split("|")[0]
        if species not in OG_sp_dict.keys():
            OG_sp_dict[species] = []
        OG_sp_dict[species].append(seq)

    # Must retain everything. Only sequences are hashable.
    dedup_list = []
    for key in list(OG_sp_dict.keys()): # Splitted by species.
        species_id_lookup = dict()
        species_seqs = OG_sp_dict[key] # Here are species' all sequences, we just want to know: if sequences are identical.
        for seq in species_seqs: # Use sequence as the key and find ids as values.
            if seq.seq not in species_id_lookup.keys():
                species_id_lookup[seq.seq] = []
            species_id_lookup[seq.seq].append(seq.id)
        print(species_id_lookup)
        species_to_dedup = remove_inparalogs(species_id_lookup) # is a list.
        # Now only retain one sequence in the copyed species paradigm.
        dedup_list += species_to_dedup

    return dedup_list

def remove_inparalogs(sp_id_dict):
    # This is only for one species'.
    sp_id_dict2 = sp_id_dict.copy()
    for key, list_id in sp_id_dict.items():
        # IF it species_wise is not single-copy.
        if len(list_id) > 1:
            # Just pick one to use. Removing others.
            dedup_id = [seqid for seqid in list_id if seqid!=list_id[0]]
            return dedup_id
        else:
            dedup_id = []
    return dedup_id
OG_Seqs = list(SeqIO.parse(args.orthogroup, "fasta"))
OG_Seqs_dedup = deduplication(OG_Seqs)
print(OG_Seqs_dedup)
print(OG_Seqs_dedup, len(OG_Seqs_dedup))
OG_dedup = [seq for seq in OG_Seqs if seq.id not in OG_Seqs_dedup]
print(len(OG_dedup))
SeqIO.write(OG_dedup, args.output, "fasta")
