from Bio import SeqIO
import argparse
import pickle as pkl
import pathlib
import os
import re

parser=argparse.ArgumentParser(description="Finds desired orthogroups with the genes selected.")
parser.add_argument("orthogroup", metavar="OG", type=pathlib.Path, help = "Path to orthogroups in fasta format.")
parser.add_argument("taxa", metavar="TAXA", type=int, help = "Expected number of taxa inside orthogroup.")
parser.add_argument("selected_genes", metavar="SG", type=str, help="The pickle file that stores selected genes.")
parser.add_argument("outputpath", metavar="OUT", type=pathlib.Path, help="Output path to store these OGs.")
# Each time this script only looks to one orthogroup and see if the identifiers are majorly taken by the gene in selected gene list.
args = parser.parse_args()

print(args.selected_genes, type(args.selected_genes))
def split_OG_by_gene(OG_seqs, selected_genes):
    # Returns a dict that keys are genes, values are the seqrecords.
    # If there are multiple genes inside OG, this function should be called.
    unique_genes_in_OG = set([seq.id for seq in OG_seqs])
    OG_gene_dict = dict()
    # Then we should modify here. 
    if len(unique_genes_in_OG)>1:
        print("Orthogroup {} has {} genes, now split them into separate groups.".format(str(args.orthogroup).split("/", 1)[-1], len(unique_genes_in_OG)))
        for i in unique_genes_in_OG:
            if i in selected_genes:
                OG_gene_dict[i] = [seq for seq in OG_seqs if seq.id == i]
            else:
                pass
    else:
        print("Orthogroup {} has only 1 gene, just store it into one dict.".format(str(args.orthogroup).split("/", 1)[-1]))
        OG_gene_dict[list(unique_genes_in_OG)[0]] = OG_seqs

    OG_dict_copy = OG_gene_dict.copy() 
    # Now OG_gene_dict is intact, we now wish to see for each gene in the orthogroup, does it contain all taxa?
    deleted_keys = []
    for gene, gene_OG in OG_dict_copy.items():
        taxonomy_OG = [seq.description.split("_", 3)[-1] for seq in gene_OG]
        if len(set(taxonomy_OG)) == args.taxa:
            continue
        else:
            deleted_keys.append(gene)
    
    for gene in deleted_keys:
        del OG_dict_copy[gene]
    # return the genes that are in selected gene lists.
    return OG_dict_copy

# Add intact identifications of whether the OG is mcog or scog.
with open(args.selected_genes, "rb") as sg:
    selected_genes = pkl.load(sg)

# We assume Orthologous groups all have over 1 sequence.
OG = list(SeqIO.parse(args.orthogroup, "fasta"))
orthogroup_name = str(args.orthogroup).split("/", -1)[-1].replace(".fa", "")
OG_genes = split_OG_by_gene(OG, selected_genes)
# Assert if there is a pre-existing path of output. If so, delete it.
if not os.path.exists(args.outputpath):
    os.mkdir(args.outputpath)

# Make a new one.
# Finally, iterate over the keys inside this dictionary, save seqs to fasta file with name: Orthogroup_name_Gene_name.fasta
for key in OG_genes:
    orthogroup_gene = OG_genes[key] # Is a list.
    output_file = orthogroup_name + "_" + key + ".fasta"
    output_file_path = os.path.join(args.outputpath, output_file)
    SeqIO.write(orthogroup_gene, output_file_path, "fasta")

# All done. 
    


