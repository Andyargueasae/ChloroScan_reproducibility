FPATH="fasta_phylo_orig/Orthosnap_input"
OPATH="fasta_phylo_orig/dedup"

for OG in $(ls $FPATH)
do
    python deduplication.py $FPATH/$OG $OPATH/$(basename $OG .fasta)_dedup.fasta
done