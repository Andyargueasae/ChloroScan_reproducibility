# This script deals with all Orthogroups and feed them into the python script: find selected marker OG.
set -e
N_TAXA=$( ls fasta_phylo_orig/ | grep .fasta | wc -l )
SELECTED_GENES="Selected_Genes.pkl"
OUTPATH="fasta_phylo_orig/Orthogroups_selected"
for OG in $(ls fasta_phylo_orig/OrthoFinder/Results_Jun16/Orthogroup_Sequences)
do
    python find_selected_marker_OGs.py "fasta_phylo_orig/OrthoFinder/Results_Jun16/Orthogroup_Sequences/$OG" $N_TAXA $SELECTED_GENES $OUTPATH

done