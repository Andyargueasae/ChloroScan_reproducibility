# generate hmm files from alignments. 
log_file="/home/student.unimelb.edu.au/yuhtong/andy/data/match_og.log"
hmms="/home/student.unimelb.edu.au/yuhtong/andy/data/dedup_scog_hmms/hmms"
alns="/home/student.unimelb.edu.au/yuhtong/andy/data/dedup_scog_hmms/aln"

set -e
#read csv file log file.
while IFS=, read -r gene og
do
    echo "Gene: $gene"
    echo "Orthogroup: $og"

    if [ ! -f $og ]; then
        echo "Orthogroup file does not exist"
        continue
    fi

    mafft --auto --thread 25 $og > $alns/$gene.aln
    echo "Alignment created for $gene, now making hmm."
    hmmbuild $hmms/$gene.hmm $alns/$gene.aln
    echo "HMM created for $og."
done < $log_file